def redondear(numero):
	print("El resultado es:  ", round(numero))