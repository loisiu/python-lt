from setuptools import setup

setup(

	name="paquetecalculos",
	version="1.0",
	description="paquete de redondeo_potencia",
	author="loi",
	author_email="vayabrands@vayabrands.com",
	packages=["calculos", "calculos.redondeo_potencia"]

	)